# -*- coding: utf-8 -*-
from scrapy.spider import CrawlSpider,Rule  
from scrapy.linkextractors import LinkExtractor  
from demo.items import MasterItem

class FangSpider(CrawlSpider):
    name = 'courses'
    allowed_domains = ['csdn.net']

    #获取多个课程列表页url
    #目前爬取的是第10页~50页
    pages=[]
    for i in range(10,50):
        url='https://edu.csdn.net/courses/k/p'+str(i)
        pages.append(url)
    start_urls = pages
       

    item = MasterItem()  
    #获取每个列表页中的课程信息url
    rules = (  
        Rule(LinkExtractor(allow=('https://edu.csdn.net/course/detail/[0-9]+',)), callback='parse_item',  
             follow=True),  
    )  

    def parse_item(self,response):  
        item = self.item  
        item['url'] = response.url  
        return item
