# -*- coding: utf-8 -*-
import scrapy
from demo.items import CourseItem
from scrapy_redis.spiders import RedisSpider

class CourseSpider(RedisSpider):
    name = 'course'
    # allowed_domains = ['fang.5i5j.com']
    # start_urls = ['https://fang.5i5j.com/bj/loupan/']
    redis_key= 'csdnspider:start_urls'

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(CourseSpider, self).__init__(*args, **kwargs)

    def parse(self, response):
        item = CourseItem()
        item['title'] = response.xpath('//div[@class="info_right no_combo no_market_price"]/h1/text()').extract_first().replace(' ','')
        item['hour'] = response.xpath('//div[@class="info_right no_combo no_market_price"]//span[@class=\"pinfo\"]/text()').extract_first()
        item['teacher'] = response.xpath('//div[@class="professor_name"]/a/text()').extract_first()
        item['student'] = response.xpath('//span[@class=\"for\"]/text()').extract_first()
        item['number'] = response.xpath('//div[@class="info_right no_combo no_market_price"]//span[@class=\"num\"]/text()').extract_first()   
        item['price'] = response.xpath('//div[@class="info_right no_combo no_market_price"]//span[@class=\"money\"]/text()').extract_first().replace(' ','').replace('\n','')
        item['content'] = response.xpath('//div[@class="outline_discribe_box J_outline_discribe_box"]/span/text()').extract_first()

        yield item
