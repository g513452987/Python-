# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request, Spider
from urllib.parse import quote
from JD_scrapy_selenium.items import ProductItem


class JdSpider(scrapy.Spider):
    name = 'jd'
    allowed_domains = ['jd.com']
    base_url = 'https://search.jd.com/Search?keyword='

    def start_requests(self):
        for keyword in self.settings.get('KEYWORDS'):
            keyword=quote(keyword)
            for page in range(1,self.settings.get('MAX_PAGE')+1):
                url=self.base_url+keyword
                yield Request(url=url,callback=self.parse,meta={'page':page},dont_filter=True)

    def parse(self, response):
        products = response.xpath('//li[@class="gl-item"]')
        for product in products:
            item = ProductItem()
            item['url']=product.xpath('.//div[@class="p-img"]//a/@href').extract_first()
            item['image'] = product.xpath('.//div[@class="p-img"]//img/@src')
            item['price'] = product.xpath('.//div[@class="p-price"]//i/text()').extract_first()
            item['commit'] = product.xpath('.//div[@class="p-commit"]//strong/a/text()').extract_first()
            title_list = product.xpath('.//div[@class="p-name p-name-type-2"]//em/text()').extract()
            t = ''
            title = ''
            for t in title_list:
                title = title + t
            item['title'] = title
            item['shop'] = product.xpath('.//div[@class="p-shop"]//a/text()').extract_first()
            yield item

